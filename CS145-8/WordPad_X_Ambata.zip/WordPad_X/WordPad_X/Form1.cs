﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Text;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Threading; 

//Ambata, Jo Simon V.
//BM1 - 2018100711


namespace WordPad_X
{
    
    public partial class Form1 : Form
    {
        string fileDir, fileName;

        public Form1()
        {
            InitializeComponent();
            rchTxtBoxWrdPad.Visible = true;
        }   

        private void saveToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // Try if a file already exists
            try
            {
                // Save file
                rchTxtBoxWrdPad.SaveFile(fileDir, RichTextBoxStreamType.RichText);

            }
            catch (Exception)
            {
                saveAsToolStripMenuItem.PerformClick();
            }

        }

        private void saveAsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (rchTxtBoxWrdPad.Visible == true)
            {
                FileDialog fd = new SaveFileDialog();

                // Save file
                if (fd.ShowDialog() == DialogResult.OK)
                {
                    fileDir = fd.FileName.ToString();

                    // Change title text
                    fileName = Path.GetFileName(fileDir);
                    this.Text = fileName + " - WordPad_X";

                    rchTxtBoxWrdPad.SaveFile(fileDir, RichTextBoxStreamType.RichText);
                }
            }
        }

        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FileDialog fd = new OpenFileDialog(); // Instantiate file dialog

            // Open file
            if (fd.ShowDialog() == DialogResult.OK)
            {
                fileDir = fd.FileName;
                // Try first if file will open successfully
                try
                {
                    rchTxtBoxWrdPad.LoadFile(fileDir);
                    rchTxtBoxWrdPad.Visible = true;

                    // Change title text
                    fileName = Path.GetFileName(fileDir);
                    this.Text = fileName + " - WordPad_X";
                }
                catch (Exception)
                {
                    MessageBox.Show("Not an RTF File!", "Error");
                }
            }
        }

        private void closeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // Clear rich text box and hide it
            rchTxtBoxWrdPad.Clear();
            rchTxtBoxWrdPad.Visible = false;

            this.Text = "WordPad_X"; // Change title text
        }

        private void chkCounter_CheckedChanged(object sender, EventArgs e)
        {
            Thread thread_count = new Thread(method_count);
  
            if (chkCounter.Checked)
            {
                thread_count.Start();
            }
            else
            {
                thread_count.Abort();
            }
        }

        private void method_count()//int is_checked, 
        {
            int j = 0;
            while(chkCounter.Checked)
            {
                String words = (String)rchTxtBoxWrdPad.Invoke(new Func<String>(() => rchTxtBoxWrdPad.Text));
                //int count = words.Split(' ').Length;
                int count = 0; int i = 0;

                // skip whitespace until first word
                while (i < words.Length && char.IsWhiteSpace(words[i]))
                    i++;

                while (i < words.Length)
                {
                    //check if current char is part of a word
                    while (i < words.Length && !char.IsWhiteSpace(words[i]))
                        i++;

                    count++;

                    //skip whitespace til next word
                    while (i < words.Length && char.IsWhiteSpace(words[i]))
                        i++;
                }
                WriteTextSafe(count.ToString());
                Thread.Sleep(100);
            }
            
                
        }

        private delegate void SafeCallDelegate(string text);

        private void WriteTextSafe(string text)
        {
            if (this.txtCount.InvokeRequired)
            {

                SafeCallDelegate d = new SafeCallDelegate(WriteTextSafe);
                txtCount.Invoke(d, new object[] { text });
                //uncheck checkbox to close properly
            }
            else
            {
                txtCount.Text = text;
            }
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            chkCounter.Checked = false;
        }


        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close(); // Close form
        }
    }
}

/*
References:
https://docs.microsoft.com/en-us/dotnet/desktop/winforms/controls/how-to-make-thread-safe-calls-to-windows-forms-controls?view=netframeworkdesktop-4.8
https://stackoverflow.com/questions/8784517/counting-number-of-words-in-c-sharp
Prof. Larry Vea's ThreadSample and Threadtest Files
 */
