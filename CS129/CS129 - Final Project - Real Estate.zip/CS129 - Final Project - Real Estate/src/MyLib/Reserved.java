package MyLib;

public class Reserved implements IState{
    public void bought(CheckStatus wrapper){
        wrapper.setCurrentState(new Bought());
    }
    public void reserved (CheckStatus wrapper){
        wrapper.setCurrentState(new Reserved());
    }
    public String printStatus(){
        return "Reserved";
    }
}
