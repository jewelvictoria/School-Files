package MyLib;

public class Buyer{
    private int customerCode;
    private String name;

    public Buyer(int customerCode, String name){
        this.customerCode = customerCode;
        this.name = name;
    }
    public int getCustomerCode(){
        return customerCode;
    }
    public String getName(){
        return name;
    }
}
