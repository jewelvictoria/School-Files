package MyLib;

public class Facade{
    private IBlock block1;
    private IBlock block2;
    private IBlock block3;
    private IBlock block4;
    private IBlock block5;
    
    public Facade(){
        block1 = new Block1();
        block2 = new Block2();
        block3 = new Block3();
        block4 = new Block4();
        block5 = new Block5();
    }
    public int doBlock1(){
        return block1.equate();
    }
    public int doBlock2(){
        return block2.equate();
    }
    public int doBlock3(){
        return block3.equate();
    }
    public int doBlock4(){
        return block4.equate();
    }
    public int doBlock5(){
        return block5.equate();
    }
}
