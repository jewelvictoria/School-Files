package MyLib;

public class CheckStatus {
    
    public IState getCurrentState() {
        return currentState;
    }

    public void setCurrentState(IState currentState) {
        this.currentState = currentState;
    }
    private IState currentState = new Bought();
    
    public void boughtState(){
        currentState.bought(this);
    }
    
    public void reservedState(){
        currentState.reserved(this);
    }
    
    public String printStatus(){
        return currentState.printStatus();
    }
    
}
