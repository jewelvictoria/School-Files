package MyLib;

public class Block1 implements IBlock{
    public int equate(){
        return 1;
    }
}
