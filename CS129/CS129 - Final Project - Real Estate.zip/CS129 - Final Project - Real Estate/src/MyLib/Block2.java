package MyLib;

public class Block2 implements IBlock{
    public int equate(){
        return 2;
    }
}
