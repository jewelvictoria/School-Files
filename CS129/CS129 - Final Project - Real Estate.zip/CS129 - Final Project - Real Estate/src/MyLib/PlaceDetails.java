package MyLib;

public class PlaceDetails extends Buyer{
    private int size;
    private int block;
    private int lot;
    private String status;

    public PlaceDetails(int customerCode, String name, int size, int block,int lot, String status){
        super(customerCode, name);
        this.size = size;
        this.block = block;
        this.lot = lot;
        this.status = status;
    }
    public int getLot(){
        return lot;
    }
    public String getStatus(){
        return status;
    }
    public int getSize(){
        return size;
    }
    public int getBlock(){
        return block;
    }
}
