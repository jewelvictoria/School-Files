package MyLib;

public class Block3 implements IBlock{
    public int equate(){
        return 3;
    }
}