package MyLib;

public interface IState {
    void bought(CheckStatus wrapper);
    void reserved(CheckStatus wrapper);
    String printStatus();
}
