package MyLib;

public class Block4 implements IBlock{
    public int equate(){
        return 4;
    }
}
