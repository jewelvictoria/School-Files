package MyLib;

public interface IBlock{
    int equate();
}
