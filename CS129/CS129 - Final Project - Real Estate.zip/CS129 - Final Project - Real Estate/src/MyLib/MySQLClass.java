package MyLib;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import javax.swing.JOptionPane;

public class MySQLClass {
    public Connection myConn = null;
    public Statement myStmt = null;
    public ResultSet myRs = null;
    CheckStatus checkStatus = new CheckStatus(); 
    
    String user = "jsvambata";
    String pass = "qweasdzxc";
    
    public void getConnection(){
        try {
            //  Get a connection to database
            myConn = DriverManager.getConnection("jdbc:mysql://localhost:3306/BUYERDB?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC", user, pass);
        }
        catch(SQLException se){
            System.out.println(se.getMessage());			
	}  
    }      
    
    public void createTable(){
        getConnection();
        try{
            myStmt = myConn.createStatement();	
            String qry = "CREATE TABLE BUYERTABLE(customerCode INT NOT NULL PRIMARY KEY auto_increment, name VARCHAR(40), size INT, block INT, lot INT, status VARCHAR(15)";	
            myStmt.executeUpdate(qry);
	}
	catch(SQLException se){
            System.out.println(se.getMessage());			
	}
    }
    public void AddRow(PlaceDetails placeDetails){
        getConnection();
        try{
            myStmt = myConn.createStatement();	
            String qry = "INSERT INTO `BUYERTABLE` VALUES("+ placeDetails.getCustomerCode() + ",'" + placeDetails.getName() + "'," + placeDetails.getSize()+ "," + placeDetails.getBlock()+", " + placeDetails.getLot() + ", " + placeDetails.getStatus() + ")";
            myStmt.executeUpdate(qry);
            myStmt.close();
            //JOptionPane.showMessageDialog(null,"Added successfully!");
	}
	catch(SQLException se){
            String msg = "Cannot add. Buyer " + placeDetails.getName() + " already exists!";
            JOptionPane.showMessageDialog(null,msg);		
	}
    }
    public void UpdateLot(int lot, int cusCode)
    {
        getConnection();
        try{
            myStmt = myConn.createStatement();	
            String qry = "UPDATE `BUYERTABLE` SET `lot` = " + lot + " WHERE `BUYERTABLE`.`customerCode`=" + cusCode;
            myStmt.executeUpdate(qry);
            myStmt.close();
            //JOptionPane.showMessageDialog(null,"Added successfully!");
	}
	catch(SQLException se){
            String msg = "Cannot add. Lot has already been purchased!";
            JOptionPane.showMessageDialog(null,msg);		
	}
    }
    
    public void TakenAlready(){
        String msg = "Invalid! Lot has already been taken!";
        JOptionPane.showMessageDialog(null,msg);
    }
    public void invalidNote(){
        String msg = "Invalid! Lot is not located in the list!";
        JOptionPane.showMessageDialog(null,msg);
    }
    public void DeleteRow(int cusCode){
        getConnection();
        try{
            myStmt = myConn.createStatement();
            String qry = "DELETE FROM BUYERTABLE WHERE customerCode = " + cusCode;
            cusCode--;
            myStmt.executeUpdate(qry);
            myStmt.close();
            JOptionPane.showMessageDialog(null,"Cancelled successfully!");
	}
	catch(SQLException se){
            System.out.println(se.getMessage());			
	}
    }
    
    public void BuyStatus(int cusCode){  
        checkStatus.boughtState();
        getConnection();
        try{
            myStmt = myConn.createStatement();	
            String qry = "UPDATE `BUYERTABLE` SET `status` = '" + checkStatus.printStatus() +"' WHERE `BUYERTABLE`.`customerCode` =  '" + cusCode + " ' ";
            myStmt.executeUpdate(qry);
            myStmt.close();
            JOptionPane.showMessageDialog(null,"Bought successfully!");
        }
        catch(SQLException se){
            String msg = "Cannot add. Status Column already exists!";
            JOptionPane.showMessageDialog(null,msg);		
        }
    }
    
    public void ReserveStatus(int cusCode){
        checkStatus.reservedState();        
        getConnection();
        try{
            myStmt = myConn.createStatement();	
            String qry = "UPDATE `BUYERTABLE` SET `status` = '" + checkStatus.printStatus() +"' WHERE `BUYERTABLE`.`customerCode` =  '" + cusCode + " ' ";
            myStmt.executeUpdate(qry);
            myStmt.close();
            JOptionPane.showMessageDialog(null,"Reserved successfully!");
        }
        catch(SQLException se){
            String msg = "Cannot add. Status Column already exists!";
            JOptionPane.showMessageDialog(null,msg);		
        }
    }
    
    public ArrayList<PlaceDetails> ShowRec(){
        ArrayList<PlaceDetails> buys = new ArrayList<PlaceDetails>();
        getConnection();
        try{
            myStmt = myConn.createStatement();	
            String query = "SELECT * FROM BUYERTABLE";
	    ResultSet rs = myStmt.executeQuery(query);
	    while(rs.next()){
                buys.add(new PlaceDetails(rs.getInt("customerCode"), rs.getString("name"), rs.getInt("size"), rs.getInt("block"), rs.getInt("lot"), rs.getString("status")));
            }
            rs.close();
	    myStmt.close();				
        }
	catch(SQLException sex){
            System.out.println(sex.getMessage());
	}
        return buys;
    }
}
