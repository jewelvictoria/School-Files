package MyLib;

public class Block5 implements IBlock{
    public int equate(){
        return 5;
    }
}
