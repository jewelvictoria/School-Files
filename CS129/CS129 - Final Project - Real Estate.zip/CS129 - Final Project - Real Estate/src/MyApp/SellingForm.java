package MyApp;

import MyLib.*;
   
public class SellingForm extends javax.swing.JFrame {
    MySQLClass msc = new MySQLClass();
    MainForm m;
    int i;
    public SellingForm(MainForm m) {
        initComponents();
        this.m = m;
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        SFormLabel = new javax.swing.JLabel();
        AvailableLots = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();
        LocationLabel = new javax.swing.JLabel();
        LotOptions = new javax.swing.JTextField();
        BuyButton = new javax.swing.JButton();
        ReserveButton = new javax.swing.JButton();
        CancelButton = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowOpened(java.awt.event.WindowEvent evt) {
                formWindowOpened(evt);
            }
        });

        SFormLabel.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        SFormLabel.setText("Selling Form");

        jTextArea1.setEditable(false);
        jTextArea1.setColumns(20);
        jTextArea1.setFont(new java.awt.Font("Monospaced", 0, 18)); // NOI18N
        jTextArea1.setRows(5);
        AvailableLots.setViewportView(jTextArea1);

        LocationLabel.setFont(new java.awt.Font("Tahoma", 0, 17)); // NOI18N
        LocationLabel.setText("Select Location: ");

        LotOptions.setFont(new java.awt.Font("Tahoma", 0, 17)); // NOI18N

        BuyButton.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        BuyButton.setText("Buy");
        BuyButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BuyButtonActionPerformed(evt);
            }
        });

        ReserveButton.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        ReserveButton.setText("Reserve");
        ReserveButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ReserveButtonActionPerformed(evt);
            }
        });

        CancelButton.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        CancelButton.setText("Cancel");
        CancelButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CancelButtonActionPerformed(evt);
            }
        });

        jLabel3.setFont(new java.awt.Font("Tahoma", 0, 17)); // NOI18N
        jLabel3.setText("Price: ");

        jLabel4.setFont(new java.awt.Font("Tahoma", 0, 17)); // NOI18N
        jLabel4.setText("------------------------");

        jLabel5.setFont(new java.awt.Font("Tahoma", 0, 17)); // NOI18N
        jLabel5.setText("Block: ");

        jLabel6.setFont(new java.awt.Font("Tahoma", 0, 21)); // NOI18N
        jLabel6.setText("Available Lots");

        jLabel7.setFont(new java.awt.Font("Tahoma", 0, 17)); // NOI18N
        jLabel7.setText("1");

        jLabel8.setFont(new java.awt.Font("Tahoma", 0, 17)); // NOI18N
        jLabel8.setText("Size of Lot: ");

        jLabel9.setFont(new java.awt.Font("Tahoma", 0, 17)); // NOI18N
        jLabel9.setText("00");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(AvailableLots)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel3)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel4))
                            .addComponent(SFormLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 157, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel6)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(LocationLabel)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(LotOptions))
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(BuyButton, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(ReserveButton, javax.swing.GroupLayout.PREFERRED_SIZE, 102, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(CancelButton)))
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel5)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel7)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel8)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel9)
                        .addGap(25, 25, 25)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(SFormLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(jLabel3))
                .addGap(15, 15, 15)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5, javax.swing.GroupLayout.DEFAULT_SIZE, 29, Short.MAX_VALUE)
                    .addComponent(jLabel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel8, javax.swing.GroupLayout.DEFAULT_SIZE, 29, Short.MAX_VALUE)
                    .addComponent(jLabel9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel6)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(AvailableLots, javax.swing.GroupLayout.PREFERRED_SIZE, 202, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(LocationLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(LotOptions, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(BuyButton, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(ReserveButton, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(CancelButton, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void CancelButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CancelButtonActionPerformed
        m.mySql.DeleteRow(m.cusCode);
        dispose();
    }//GEN-LAST:event_CancelButtonActionPerformed

    private void BuyButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BuyButtonActionPerformed
        //Exception Handling for Buying the Lot
        if(m.block == 1){
            switch (m.lotSize){
                case 70:
                    if(Double.parseDouble(LotOptions.getText()) >= 1 && Double.parseDouble(LotOptions.getText()) <= 5){
                        if((m.b1[Integer.parseInt(LotOptions.getText())] % 10) != 1){
                            m.b1[Integer.parseInt(LotOptions.getText())]++;
                            runBuy();
                        }
                        else{
                            msc.TakenAlready();
                        }
                    }
                    else{
                        msc.invalidNote();
                    }
                    break;
                case 100:
                    if(Double.parseDouble(LotOptions.getText()) >= 6 && Double.parseDouble(LotOptions.getText()) <= 10){
                        if((m.b1[Integer.parseInt(LotOptions.getText())] % 10) != 1){
                            m.b1[Integer.parseInt(LotOptions.getText())]++;
                            runBuy();
                        }
                        else{
                            msc.TakenAlready();
                        }
                    }
                    else{
                        msc.invalidNote();
                    }
                    break;
                case 120:
                    if(Double.parseDouble(LotOptions.getText()) >= 11 && Double.parseDouble(LotOptions.getText()) <= 15){
                        if((m.b1[Integer.parseInt(LotOptions.getText())] % 10) != 1){
                            m.b1[Integer.parseInt(LotOptions.getText())]++;
                            runBuy();
                        }
                        else{
                            msc.TakenAlready();
                        }
                    }
                    else{
                        msc.invalidNote();
                    }
                    break;
                case 150:
                    if(Double.parseDouble(LotOptions.getText()) >= 16 && Double.parseDouble(LotOptions.getText()) <= 20){
                        if((m.b1[Integer.parseInt(LotOptions.getText())] % 10) != 1){
                            m.b1[Integer.parseInt(LotOptions.getText())]++;
                            runBuy();
                        }
                        else{
                            msc.TakenAlready();
                        }
                    }
                    else{
                        msc.invalidNote();
                    }
                    break;
                default:
                    break;
            }
        }

        if(m.block == 2){
            switch (m.lotSize){
                case 70:
                    if(Double.parseDouble(LotOptions.getText()) >= 1 && Double.parseDouble(LotOptions.getText()) <= 5){
                        if((m.b2[Integer.parseInt(LotOptions.getText())] % 10) != 1){
                            m.b2[Integer.parseInt(LotOptions.getText())]++;
                            runBuy();
                        }
                        else{
                            msc.TakenAlready();
                        }
                    }
                    else{
                        msc.invalidNote();
                    }
                    break;
                case 100:
                    if(Double.parseDouble(LotOptions.getText()) >= 6 && Double.parseDouble(LotOptions.getText()) <= 10){
                        if((m.b2[Integer.parseInt(LotOptions.getText())] % 10) != 1){
                            m.b2[Integer.parseInt(LotOptions.getText())]++;
                            runBuy();
                        }
                        else{
                            msc.TakenAlready();
                        }
                    }
                    else{
                        msc.invalidNote();
                    }
                    break;
                case 120:
                    if(Double.parseDouble(LotOptions.getText()) >= 11 && Double.parseDouble(LotOptions.getText()) <= 15){
                        if((m.b2[Integer.parseInt(LotOptions.getText())] % 10) != 1){
                            m.b2[Integer.parseInt(LotOptions.getText())]++;
                            runBuy();
                        }
                        else{
                            msc.TakenAlready();
                        }
                    }
                    else{
                        msc.invalidNote();
                    }
                    break;
                case 150:
                    if(Double.parseDouble(LotOptions.getText()) >= 16 && Double.parseDouble(LotOptions.getText()) <= 20){
                        if((m.b2[Integer.parseInt(LotOptions.getText())] % 10) != 1){
                            m.b2[Integer.parseInt(LotOptions.getText())]++;
                            runBuy();
                        }
                        else{
                            msc.TakenAlready();
                        }
                    }
                    else{
                        msc.invalidNote();
                    }
                    break;
                default:
                    break;
            }
        }

        if(m.block == 3){
            switch (m.lotSize){
                case 70:
                    if(Double.parseDouble(LotOptions.getText()) >= 1 && Double.parseDouble(LotOptions.getText()) <= 5){
                        if((m.b3[Integer.parseInt(LotOptions.getText())] % 10) != 1){
                            m.b3[Integer.parseInt(LotOptions.getText())]++;
                            runBuy();
                        }
                        else{
                            msc.TakenAlready();
                        }
                    }
                    else{
                        msc.invalidNote();
                    }
                    break;
                case 100:
                    if(Double.parseDouble(LotOptions.getText()) >= 6 && Double.parseDouble(LotOptions.getText()) <= 10){
                        if((m.b3[Integer.parseInt(LotOptions.getText())] % 10) != 1){
                            m.b3[Integer.parseInt(LotOptions.getText())]++;
                            runBuy();
                        }
                        else{
                            msc.TakenAlready();
                        }
                    }
                    else{
                        msc.invalidNote();
                    }
                    break;
                case 120:
                    if(Double.parseDouble(LotOptions.getText()) >= 11 && Double.parseDouble(LotOptions.getText()) <= 15){
                        if((m.b3[Integer.parseInt(LotOptions.getText())] % 10) != 1){
                            m.b3[Integer.parseInt(LotOptions.getText())]++;
                            runBuy();
                        }
                        else{
                            msc.TakenAlready();
                        }
                    }
                    else{
                        msc.invalidNote();
                    }
                    break;
                case 150:
                    if(Double.parseDouble(LotOptions.getText()) >= 16 && Double.parseDouble(LotOptions.getText()) <= 20){
                        if((m.b3[Integer.parseInt(LotOptions.getText())] % 10) != 1){
                            m.b3[Integer.parseInt(LotOptions.getText())]++;
                            runBuy();
                        }
                        else{
                            msc.TakenAlready();
                        }
                    }
                    else{
                        msc.invalidNote();
                    }
                    break;
                default:
                    break;
            }
        }

        if(m.block == 4){
            switch (m.lotSize){
                case 70:
                    if(Double.parseDouble(LotOptions.getText()) >= 1 && Double.parseDouble(LotOptions.getText()) <= 5){
                        if((m.b4[Integer.parseInt(LotOptions.getText())] % 10) != 1){
                            m.b4[Integer.parseInt(LotOptions.getText())]++;
                            runBuy();
                        }
                        else{
                            msc.TakenAlready();
                        }
                    }
                    else{
                        msc.invalidNote();
                    }
                    break;
                case 100:
                    if(Double.parseDouble(LotOptions.getText()) >= 6 && Double.parseDouble(LotOptions.getText()) <= 10){
                        if((m.b4[Integer.parseInt(LotOptions.getText())] % 10) != 1){
                            m.b4[Integer.parseInt(LotOptions.getText())]++;
                            runBuy();
                        }
                        else{
                            msc.TakenAlready();
                        }
                    }
                    else{
                        msc.invalidNote();
                    }
                    break;
                case 120:
                    if(Double.parseDouble(LotOptions.getText()) >= 11 && Double.parseDouble(LotOptions.getText()) <= 15){
                        if((m.b4[Integer.parseInt(LotOptions.getText())] % 10) != 1){
                            m.b4[Integer.parseInt(LotOptions.getText())]++;
                            runBuy();
                        }
                        else{
                            msc.TakenAlready();
                        }
                    }
                    else{
                        msc.invalidNote();
                    }
                    break;
                case 150:
                    if(Double.parseDouble(LotOptions.getText()) >= 16 && Double.parseDouble(LotOptions.getText()) <= 20){
                        if((m.b4[Integer.parseInt(LotOptions.getText())] % 10) != 1){
                            m.b4[Integer.parseInt(LotOptions.getText())]++;
                            runBuy();
                        }
                        else{
                            msc.TakenAlready();
                        }
                    }
                    else{
                        msc.invalidNote();
                    }
                    break;
                default:
                    break;
            }
        }

        if(m.block == 5){
            switch (m.lotSize){
                case 70:
                    if(Double.parseDouble(LotOptions.getText()) >= 1 && Double.parseDouble(LotOptions.getText()) <= 5){
                        if((m.b5[Integer.parseInt(LotOptions.getText())] % 10) != 1){
                            m.b5[Integer.parseInt(LotOptions.getText())]++;
                            runBuy();
                        }
                        else{
                            msc.TakenAlready();
                        }
                    }
                    else{
                        msc.invalidNote();
                    }
                    break;
                case 100:
                    if(Double.parseDouble(LotOptions.getText()) >= 6 && Double.parseDouble(LotOptions.getText()) <= 10){
                        if((m.b5[Integer.parseInt(LotOptions.getText())] % 10) != 1){
                            m.b5[Integer.parseInt(LotOptions.getText())]++;
                            runBuy();
                        }
                        else{
                            msc.TakenAlready();
                        }
                    }
                    else{
                        msc.invalidNote();
                    }
                    break;
                case 120:
                    if(Double.parseDouble(LotOptions.getText()) >= 11 && Double.parseDouble(LotOptions.getText()) <= 15){
                        if((m.b5[Integer.parseInt(LotOptions.getText())] % 10) != 1){
                            m.b5[Integer.parseInt(LotOptions.getText())]++;
                            runBuy();
                        }
                        else{
                            msc.TakenAlready();
                        }
                    }
                    else{
                        msc.invalidNote();
                    }
                    break;
                case 150:
                    if(Double.parseDouble(LotOptions.getText()) >= 16 && Double.parseDouble(LotOptions.getText()) <= 20){
                        if((m.b5[Integer.parseInt(LotOptions.getText())] % 10) != 1){
                            m.b5[Integer.parseInt(LotOptions.getText())]++;
                            runBuy();
                        }
                        else{
                            msc.TakenAlready();
                        }
                    }
                    else{
                        msc.invalidNote();
                    }
                    break;
                default:
                    break;
            }
        }
    }//GEN-LAST:event_BuyButtonActionPerformed

    private void ReserveButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ReserveButtonActionPerformed
        //Exception Handling for Reserving the Lot
        if(m.block == 1){
            switch (m.lotSize){
                case 70:
                    if(Double.parseDouble(LotOptions.getText()) >= 1 && Double.parseDouble(LotOptions.getText()) <= 5){
                        if((m.b1[Integer.parseInt(LotOptions.getText())] % 10) != 1){
                            m.b1[Integer.parseInt(LotOptions.getText())]++;
                            runReserve();
                        }
                        else{
                            msc.TakenAlready();
                        }
                    }
                    else{
                        msc.invalidNote();
                    }
                    break;
                case 100:
                    if(Double.parseDouble(LotOptions.getText()) >= 6 && Double.parseDouble(LotOptions.getText()) <= 10){
                        if((m.b1[Integer.parseInt(LotOptions.getText())] % 10) != 1){
                            m.b1[Integer.parseInt(LotOptions.getText())]++;
                            runReserve();
                        }
                        else{
                            msc.TakenAlready();
                        }
                    }
                    else{
                        msc.invalidNote();
                    }
                    break;
                case 120:
                    if(Double.parseDouble(LotOptions.getText()) >= 11 && Double.parseDouble(LotOptions.getText()) <= 15){
                        if((m.b1[Integer.parseInt(LotOptions.getText())] % 10) != 1){
                            m.b1[Integer.parseInt(LotOptions.getText())]++;
                            runReserve();
                        }
                        else{
                            msc.TakenAlready();
                        }
                    }
                    else{
                        msc.invalidNote();
                    }
                    break;
                case 150:
                    if(Double.parseDouble(LotOptions.getText()) >= 16 && Double.parseDouble(LotOptions.getText()) <= 20){
                        if((m.b1[Integer.parseInt(LotOptions.getText())] % 10) != 1){
                            m.b1[Integer.parseInt(LotOptions.getText())]++;
                            runReserve();
                        }
                        else{
                            msc.TakenAlready();
                        }
                    }
                    else{
                        msc.invalidNote();
                    }
                    break;
                default:
                    break;
            }
        }
        
        else if(m.block == 2){
            switch (m.lotSize){
                case 70:
                    if(Double.parseDouble(LotOptions.getText()) >= 1 && Double.parseDouble(LotOptions.getText()) <= 5){
                        if((m.b2[Integer.parseInt(LotOptions.getText())] % 10) != 1){
                            m.b2[Integer.parseInt(LotOptions.getText())]++;
                            runReserve();
                        }
                        else{
                            msc.TakenAlready();
                        }
                    }
                    else{
                        msc.invalidNote();
                    }
                    break;
                case 100:
                    if(Double.parseDouble(LotOptions.getText()) >= 6 && Double.parseDouble(LotOptions.getText()) <= 10){
                        if((m.b2[Integer.parseInt(LotOptions.getText())] % 10) != 1){
                            m.b2[Integer.parseInt(LotOptions.getText())]++;
                            runReserve();
                        }
                        else{
                            msc.TakenAlready();
                        }
                    }
                    else{
                        msc.invalidNote();
                    }
                    break;
                case 120:
                    if(Double.parseDouble(LotOptions.getText()) >= 11 && Double.parseDouble(LotOptions.getText()) <= 15){
                        if((m.b2[Integer.parseInt(LotOptions.getText())] % 10) != 1){
                            m.b2[Integer.parseInt(LotOptions.getText())]++;
                            runReserve();
                        }
                        else{
                            msc.TakenAlready();
                        }
                    }
                    else{
                        msc.invalidNote();
                    }
                    break;
                case 150:
                    if(Double.parseDouble(LotOptions.getText()) >= 16 && Double.parseDouble(LotOptions.getText()) <= 20){
                        if((m.b2[Integer.parseInt(LotOptions.getText())] % 10) != 1){
                            m.b2[Integer.parseInt(LotOptions.getText())]++;
                            runReserve();
                        }
                        else{
                            msc.TakenAlready();
                        }
                    }
                    else{
                        msc.invalidNote();
                    }
                    break;
                default:
                    break;
            }
        }
        
        else if(m.block == 3){
            switch (m.lotSize){
                case 70:
                    if(Double.parseDouble(LotOptions.getText()) >= 1 && Double.parseDouble(LotOptions.getText()) <= 5){
                        if((m.b3[Integer.parseInt(LotOptions.getText())] % 10) != 1){
                            m.b3[Integer.parseInt(LotOptions.getText())]++;
                            runReserve();
                        }
                        else{
                            msc.TakenAlready();
                        }
                    }
                    else{
                        msc.invalidNote();
                    }
                    break;
                case 100:
                    if(Double.parseDouble(LotOptions.getText()) >= 6 && Double.parseDouble(LotOptions.getText()) <= 10){
                        if((m.b3[Integer.parseInt(LotOptions.getText())] % 10) != 1){
                            m.b3[Integer.parseInt(LotOptions.getText())]++;
                            runReserve();
                        }
                        else{
                            msc.TakenAlready();
                        }
                    }
                    else{
                        msc.invalidNote();
                    }
                    break;
                case 120:
                    if(Double.parseDouble(LotOptions.getText()) >= 11 && Double.parseDouble(LotOptions.getText()) <= 15){
                        if((m.b3[Integer.parseInt(LotOptions.getText())] % 10) != 1){
                            m.b3[Integer.parseInt(LotOptions.getText())]++;
                            runReserve();
                        }
                        else{
                            msc.TakenAlready();
                        }
                    }
                    else{
                        msc.invalidNote();
                    }
                    break;
                case 150:
                    if(Double.parseDouble(LotOptions.getText()) >= 16 && Double.parseDouble(LotOptions.getText()) <= 20){
                        if((m.b3[Integer.parseInt(LotOptions.getText())] % 10) != 1){
                            m.b3[Integer.parseInt(LotOptions.getText())]++;
                            runReserve();
                        }
                        else{
                            msc.TakenAlready();
                        }
                    }
                    else{
                        msc.invalidNote();
                    }
                    break;
                default:
                    break;
            }
        }
        
        else if(m.block == 4){
            switch (m.lotSize){
                case 70:
                    if(Double.parseDouble(LotOptions.getText()) >= 1 && Double.parseDouble(LotOptions.getText()) <= 5){
                        if((m.b4[Integer.parseInt(LotOptions.getText())] % 10) != 1){
                            m.b4[Integer.parseInt(LotOptions.getText())]++;
                            runReserve();
                        }
                        else{
                            msc.TakenAlready();
                        }
                    }
                    else{
                        msc.invalidNote();
                    }
                    break;
                case 100:
                    if(Double.parseDouble(LotOptions.getText()) >= 6 && Double.parseDouble(LotOptions.getText()) <= 10){
                        if((m.b4[Integer.parseInt(LotOptions.getText())] % 10) != 1){
                            m.b4[Integer.parseInt(LotOptions.getText())]++;
                            runReserve();
                        }
                        else{
                            msc.TakenAlready();
                        }
                    }
                    else{
                        msc.invalidNote();
                    }
                    break;
                case 120:
                    if(Double.parseDouble(LotOptions.getText()) >= 11 && Double.parseDouble(LotOptions.getText()) <= 15){
                        if((m.b4[Integer.parseInt(LotOptions.getText())] % 10) != 1){
                            m.b4[Integer.parseInt(LotOptions.getText())]++;
                            runReserve();
                        }
                        else{
                            msc.TakenAlready();
                        }
                    }
                    else{
                        msc.invalidNote();
                    }
                    break;
                case 150:
                    if(Double.parseDouble(LotOptions.getText()) >= 16 && Double.parseDouble(LotOptions.getText()) <= 20){
                        if((m.b4[Integer.parseInt(LotOptions.getText())] % 10) != 1){
                            m.b4[Integer.parseInt(LotOptions.getText())]++;
                            runReserve();
                        }
                        else{
                            msc.TakenAlready();
                        }
                    }
                    else{
                        msc.invalidNote();
                    }
                    break;
                default:
                    break;
            }
        }
        
        else if(m.block == 5){
            switch (m.lotSize){
                case 70:
                    if(Double.parseDouble(LotOptions.getText()) >= 1 && Double.parseDouble(LotOptions.getText()) <= 5){
                        if((m.b5[Integer.parseInt(LotOptions.getText())] % 10) != 1){
                            m.b5[Integer.parseInt(LotOptions.getText())]++;
                            runReserve();
                        }
                        else{
                            msc.TakenAlready();
                        }
                    }
                    else{
                        msc.invalidNote();
                    }
                    break;
                case 100:
                    if(Double.parseDouble(LotOptions.getText()) >= 6 && Double.parseDouble(LotOptions.getText()) <= 10){
                        if((m.b5[Integer.parseInt(LotOptions.getText())] % 10) != 1){
                            m.b5[Integer.parseInt(LotOptions.getText())]++;
                            runReserve();
                        }
                        else{
                            msc.TakenAlready();
                        }
                    }
                    else{
                        msc.invalidNote();
                    }
                    break;
                case 120:
                    if(Double.parseDouble(LotOptions.getText()) >= 11 && Double.parseDouble(LotOptions.getText()) <= 15){
                        if((m.b5[Integer.parseInt(LotOptions.getText())] % 10) != 1){
                            m.b5[Integer.parseInt(LotOptions.getText())]++;
                            runReserve();
                        }
                        else{
                            msc.TakenAlready();
                        }
                    }
                    else{
                        msc.invalidNote();
                    }
                    break;
                case 150:
                    if(Double.parseDouble(LotOptions.getText()) >= 16 && Double.parseDouble(LotOptions.getText()) <= 20){
                        if((m.b5[Integer.parseInt(LotOptions.getText())] % 10) != 1){
                            m.b5[Integer.parseInt(LotOptions.getText())]++;
                            runReserve();
                        }
                        else{
                            msc.TakenAlready();
                        }
                    }
                    else{
                        msc.invalidNote();
                    }
                    break;
                default:
                    break;
            }
        }
    }//GEN-LAST:event_ReserveButtonActionPerformed

    private void formWindowOpened(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowOpened
        jLabel7.setText(String.valueOf(m.block));
        jLabel4.setText("P " + m.price);
        jLabel9.setText(String.valueOf(m.lotSize) + " sqm.");
         
        //Shows Available Lots
        if(m.lotSize==70){
            switch (m.block) {
                case 1:
                    for(i = 0; i < m.b1.length; i++){
                        if(m.b1[i] == 70){
                            jTextArea1.append(String.valueOf(i) + "\n");
                        }
                    }
                    break;
                case 2:
                    for(i = 0; i < m.b2.length; i++){
                        if(m.b2[i] == 70){
                            jTextArea1.append(String.valueOf(i) + "\n");
                        }
                    }
                    break;
                case 3:
                    for(i = 0; i < m.b3.length; i++){
                        if(m.b3[i] == 70){
                            jTextArea1.append(String.valueOf(i) + "\n");
                        }
                    }
                    break;
                case 4:
                    for(i = 0; i < m.b4.length; i++){
                        if(m.b4[i] == 70){
                            jTextArea1.append(String.valueOf(i) + "\n");
                        }
                    }
                    break;
                case 5:
                    for(i = 0; i < m.b5.length; i++){
                        if(m.b5[i] == 70){
                            jTextArea1.append(String.valueOf(i) + "\n");
                        }
                    }
                    break;
                default:
                    break;
            }
        }
        //Lot Size == 100
        if(m.lotSize==100){
            switch (m.block) {
                case 1:
                    for(i = 0; i < m.b1.length; i++){
                        if(m.b1[i] == 100){
                            jTextArea1.append(String.valueOf(i) + "\n");
                        }
                    }
                    break;
                case 2:
                    for(i = 0; i < m.b2.length; i++){
                        if(m.b2[i] == 100){
                            jTextArea1.append(String.valueOf(i) + "\n");
                        }
                    }
                    break;
                case 3:
                    for(i = 0; i < m.b3.length; i++){
                        if(m.b3[i] == 100){
                            jTextArea1.append(String.valueOf(i) + "\n");
                        }
                    }
                    break;
                case 4:
                    for(i = 0; i < m.b4.length; i++){
                        if(m.b4[i] == 100){
                            jTextArea1.append(String.valueOf(i) + "\n");
                        }
                    }
                    break;
                case 5:
                    for(i = 0; i < m.b5.length; i++){
                        if(m.b5[i] == 100){
                            jTextArea1.append(String.valueOf(i) + "\n");
                        }
                    }
                    break;
                default:
                    break;
            }
        }
        //Lot Size == 120
        if(m.lotSize==120){
            switch (m.block) {
                case 1:
                    for(i = 0; i < m.b1.length; i++){
                        if(m.b1[i] == 120){
                            jTextArea1.append(String.valueOf(i) + "\n");
                        }
                    }
                    break;
                case 2:
                    for(i = 0; i < m.b2.length; i++){
                        if(m.b2[i] == 120){
                            jTextArea1.append(String.valueOf(i) + "\n");
                        }
                    }
                    break;
                case 3:
                    for(i = 0; i < m.b3.length; i++){
                        if(m.b3[i] == 120){
                            jTextArea1.append(String.valueOf(i) + "\n");
                        }
                    }
                    break;
                case 4:
                    for(i = 0; i < m.b4.length; i++){
                        if(m.b4[i] == 120){
                            jTextArea1.append(String.valueOf(i) + "\n");
                        }
                    }
                    break;
                case 5:
                    for(i = 0; i < m.b5.length; i++){
                        if(m.b5[i] == 120){
                            jTextArea1.append(String.valueOf(i) + "\n");
                        }
                    }
                    break;
                default:
                    break;
            }
        }
        //Lot Size == 150
        if(m.lotSize==150){
            switch (m.block) {
                case 1:
                    for(i = 0; i < m.b1.length; i++){
                        if(m.b1[i] == 150){
                            jTextArea1.append(String.valueOf(i) + "\n");
                        }
                    }
                    break;
                case 2:
                    for(i = 0; i < m.b2.length; i++){
                        if(m.b2[i] == 150){
                            jTextArea1.append(String.valueOf(i) + "\n");
                        }
                    }
                    break;
                case 3:
                    for(i = 0; i < m.b3.length; i++){
                        if(m.b3[i] == 150){
                            jTextArea1.append(String.valueOf(i) + "\n");
                        }
                    }
                    break;
                case 4:
                    for(i = 0; i < m.b4.length; i++){
                        if(m.b4[i] == 150){
                            jTextArea1.append(String.valueOf(i) + "\n");
                        }
                    }
                    break;
                case 5:
                    for(i = 0; i < m.b5.length; i++){
                        if(m.b5[i] == 150){
                            jTextArea1.append(String.valueOf(i) + "\n");
                        }
                    }
                    break;
                default:
                    break;
            }
        }
    }//GEN-LAST:event_formWindowOpened
    public void runBuy(){//Buying the Lot
        m.lot = Integer.parseInt(LotOptions.getText());
        m.mySql.UpdateLot(m.lot, m.cusCode);
        m.mySql.BuyStatus(m.cusCode);
        m.cusCode++;
        m.getCustCode().setText(String.valueOf(m.cusCode));
        dispose();
    }
    public void runReserve(){//Reserving the Lot
        m.lot = Integer.parseInt(LotOptions.getText());
        m.mySql.UpdateLot(m.lot, m.cusCode);
        m.mySql.ReserveStatus(m.cusCode);
        m.cusCode++;
        m.getCustCode().setText(String.valueOf(m.cusCode));
        dispose();
    }
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(SellingForm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(SellingForm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(SellingForm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(SellingForm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                //new SellingForm().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JScrollPane AvailableLots;
    private javax.swing.JButton BuyButton;
    private javax.swing.JButton CancelButton;
    private javax.swing.JLabel LocationLabel;
    private javax.swing.JTextField LotOptions;
    private javax.swing.JButton ReserveButton;
    private javax.swing.JLabel SFormLabel;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JTextArea jTextArea1;
    // End of variables declaration//GEN-END:variables
}
