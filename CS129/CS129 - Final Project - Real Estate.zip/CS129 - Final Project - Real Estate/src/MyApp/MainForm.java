/*
@author BM1 - Abundo - Ambata - Bonifacio - Jacinto - Moncayo
BM1 - CS129-8L
*/
package MyApp;

import MyLib.*;
import java.util.ArrayList;
import javax.swing.ButtonGroup;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public class MainForm extends javax.swing.JFrame {
    MySQLClass mySql=new MySQLClass();
    Facade facade = new Facade();
    public ArrayList<PlaceDetails> placeDetails;
    DefaultTableModel model;
    public int cusCode = 1000,lotSize=0, block=1, lot=0;
    String status = null;
    double price;
    int[] b1 =new int[21];
    int[] b2 =new int[21];
    int[] b3 =new int[21];
    int[] b4 =new int[21];
    int[] b5 =new int[21];
    int i;
    
    public MainForm() {
        initComponents();
        ButtonGroup buttonGroup = new ButtonGroup();
        buttonGroup.add(LotSize1);
        buttonGroup.add(LotSize2);
        buttonGroup.add(LotSize3);
        buttonGroup.add(LotSize4);
        LotSize1.doClick();
        //size 70
        for(i = 1; i<=5;i++){
            b1[i] = 70;
            b2[i] = 70;
            b3[i] = 70;
            b4[i] = 70;
            b5[i] = 70;
        }
        //size 100
        for(i = 6; i<=10;i++){
            b1[i] = 100;
            b2[i] = 100;
            b3[i] = 100;
            b4[i] = 100;
            b5[i] = 100;
        }
        //size 120
        for(i = 11; i<=15;i++){
            b1[i] = 120;
            b2[i] = 120;
            b3[i] = 120;
            b4[i] = 120;
            b5[i] = 120;
        }
        //size 150
        for(i = 16; i<=20;i++){
            b1[i] = 150;
            b2[i] = 150;
            b3[i] = 150;
            b4[i] = 150;
            b5[i] = 150;
        }
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        ProjectTitle = new javax.swing.JLabel();
        CompanyName = new javax.swing.JLabel();
        BuyerName = new javax.swing.JLabel();
        NameInput = new javax.swing.JTextField();
        LotSizes = new javax.swing.JLabel();
        BlockLocations = new javax.swing.JLabel();
        PriceLabel = new javax.swing.JLabel();
        SubmitButton = new javax.swing.JButton();
        PriceDisplay = new javax.swing.JLabel();
        LotSize1 = new javax.swing.JRadioButton();
        LotSize2 = new javax.swing.JRadioButton();
        LotSize3 = new javax.swing.JRadioButton();
        LotSize4 = new javax.swing.JRadioButton();
        BlockOptions = new javax.swing.JComboBox<>();
        ReportButton = new javax.swing.JButton();
        cusCodeLabel = new javax.swing.JLabel();
        custCode = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setForeground(new java.awt.Color(240, 240, 240));
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowOpened(java.awt.event.WindowEvent evt) {
                formWindowOpened(evt);
            }
        });

        ProjectTitle.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        ProjectTitle.setText("Real-Estate Sales & Management System");

        CompanyName.setFont(new java.awt.Font("Copperplate Gothic Light", 1, 36)); // NOI18N
        CompanyName.setText("Echan's Estate");

        BuyerName.setFont(new java.awt.Font("Tahoma", 0, 17)); // NOI18N
        BuyerName.setText("Buyer's Name:");

        NameInput.setFont(new java.awt.Font("Tahoma", 0, 17)); // NOI18N

        LotSizes.setFont(new java.awt.Font("Tahoma", 0, 17)); // NOI18N
        LotSizes.setText("Desired Lot Size:");

        BlockLocations.setFont(new java.awt.Font("Tahoma", 0, 17)); // NOI18N
        BlockLocations.setText("Block Location:");

        PriceLabel.setFont(new java.awt.Font("Tahoma", 0, 17)); // NOI18N
        PriceLabel.setText("Price: ");

        SubmitButton.setFont(new java.awt.Font("Tahoma", 0, 17)); // NOI18N
        SubmitButton.setText("Submit");
        SubmitButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SubmitButtonActionPerformed(evt);
            }
        });

        PriceDisplay.setFont(new java.awt.Font("Tahoma", 0, 17)); // NOI18N
        PriceDisplay.setText("P----------------------------------");

        LotSize1.setText("70 sqm");
        LotSize1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                LotSize1ActionPerformed(evt);
            }
        });

        LotSize2.setText("100 sqm");
        LotSize2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                LotSize2ActionPerformed(evt);
            }
        });

        LotSize3.setText("120 sqm");
        LotSize3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                LotSize3ActionPerformed(evt);
            }
        });

        LotSize4.setText("150 sqm");
        LotSize4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                LotSize4ActionPerformed(evt);
            }
        });

        BlockOptions.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "1","2","3","4","5" }));
        BlockOptions.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BlockOptionsActionPerformed(evt);
            }
        });

        ReportButton.setFont(new java.awt.Font("Tahoma", 0, 17)); // NOI18N
        ReportButton.setText("Generate Report");
        ReportButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ReportButtonActionPerformed(evt);
            }
        });

        cusCodeLabel.setFont(new java.awt.Font("Tahoma", 0, 17)); // NOI18N
        cusCodeLabel.setText("Customer Code: ");

        custCode.setFont(new java.awt.Font("Tahoma", 0, 17)); // NOI18N
        custCode.setText("1000");

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "Customer Code", "Name", "Lot Size", "Block", "Lot ", "Status"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(jTable1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(118, 118, 118)
                                        .addComponent(SubmitButton, javax.swing.GroupLayout.PREFERRED_SIZE, 179, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(layout.createSequentialGroup()
                                        .addContainerGap()
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(layout.createSequentialGroup()
                                                .addComponent(LotSizes, javax.swing.GroupLayout.PREFERRED_SIZE, 127, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                .addComponent(LotSize1)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                .addComponent(LotSize2))
                                            .addGroup(layout.createSequentialGroup()
                                                .addComponent(BlockLocations, javax.swing.GroupLayout.PREFERRED_SIZE, 127, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                .addComponent(BlockOptions, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                .addComponent(PriceLabel)))))
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(layout.createSequentialGroup()
                                                .addComponent(LotSize3)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                .addComponent(LotSize4))
                                            .addComponent(PriceDisplay, javax.swing.GroupLayout.PREFERRED_SIZE, 268, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(54, 54, 54)
                                        .addComponent(ReportButton, javax.swing.GroupLayout.PREFERRED_SIZE, 179, javax.swing.GroupLayout.PREFERRED_SIZE))))
                            .addGroup(layout.createSequentialGroup()
                                .addContainerGap()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(BuyerName, javax.swing.GroupLayout.PREFERRED_SIZE, 127, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(cusCodeLabel, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 127, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(NameInput, javax.swing.GroupLayout.PREFERRED_SIZE, 270, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(custCode)))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(60, 60, 60)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(CompanyName)
                                    .addComponent(ProjectTitle))))
                        .addGap(0, 57, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane1)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(ProjectTitle, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(CompanyName, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(3, 3, 3)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(cusCodeLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(custCode, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(BuyerName, javax.swing.GroupLayout.DEFAULT_SIZE, 40, Short.MAX_VALUE)
                    .addComponent(NameInput))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(LotSizes, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(LotSize1)
                    .addComponent(LotSize2)
                    .addComponent(LotSize3)
                    .addComponent(LotSize4))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(BlockLocations, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(BlockOptions, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(PriceDisplay)
                    .addComponent(PriceLabel))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(SubmitButton, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(ReportButton, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 239, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void SubmitButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SubmitButtonActionPerformed
        String name = NameInput.getText();
        PlaceDetails placeDetails=new PlaceDetails(cusCode, name, lotSize, block, lot, status);
        mySql.AddRow(placeDetails);
        SellingForm form = new SellingForm(this);
        form.setVisible(true);
        NameInput.setText("");
    }//GEN-LAST:event_SubmitButtonActionPerformed

    private void BlockOptionsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BlockOptionsActionPerformed
        JComboBox comboBox = (JComboBox) evt.getSource();
        String cB = (String) comboBox.getSelectedItem();
        if(null != cB)switch (cB) {
            case "1":
                block = facade.doBlock1();
                break;
            case "2":
                block = facade.doBlock2();
                break;
            case "3":
                block = facade.doBlock3();
                break;
            case "4":
                block = facade.doBlock4();
                break;
            case "5": 
                block = facade.doBlock5();
                break;
            default:
                break;
        }
        
    }//GEN-LAST:event_BlockOptionsActionPerformed

    private void LotSize1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_LotSize1ActionPerformed
        lotSize = 70;
        price = 14240.00*70.00;
        PriceDisplay.setText("P " + price);
    }//GEN-LAST:event_LotSize1ActionPerformed

    private void LotSize2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_LotSize2ActionPerformed
        lotSize = 100;
        price = 14240.00*100.00;
        PriceDisplay.setText("P " + price);
    }//GEN-LAST:event_LotSize2ActionPerformed

    private void ReportButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ReportButtonActionPerformed
        DisplayTable();
        placeDetails = mySql.ShowRec();
        
        model = (DefaultTableModel) jTable1.getModel();
        for(PlaceDetails p: placeDetails){
            model.addRow(new Object [] {p.getCustomerCode(), p.getName(), p.getSize(), p.getBlock(), p.getLot(), p.getStatus()});
        }
    }//GEN-LAST:event_ReportButtonActionPerformed

    private void LotSize3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_LotSize3ActionPerformed
        lotSize = 120;
        price = 14240.00*120.00;
        PriceDisplay.setText("P " + price);
    }//GEN-LAST:event_LotSize3ActionPerformed

    private void LotSize4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_LotSize4ActionPerformed
        lotSize = 150;
        price = 14240.00*150.00;
        PriceDisplay.setText("P " + price);
    }//GEN-LAST:event_LotSize4ActionPerformed

    private void formWindowOpened(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowOpened
        DisplayTable();
        placeDetails = mySql.ShowRec();
        
        model = (DefaultTableModel) jTable1.getModel();
        for(PlaceDetails p: placeDetails){
            if(cusCode == p.getCustomerCode()){
                cusCode++;
                custCode.setText(String.valueOf(cusCode));
            }
        }
        for(PlaceDetails p: placeDetails){
            model.addRow(new Object [] {p.getCustomerCode(), p.getName(), p.getSize(), p.getBlock(), p.getLot(), p.getStatus()});
        }
    }//GEN-LAST:event_formWindowOpened
    
    public void DisplayTable(){
        
        model=(DefaultTableModel) jTable1.getModel();
        model.getDataVector().removeAllElements();
        model.fireTableDataChanged();
    }

    public ArrayList<PlaceDetails> getBuyers() {
        return placeDetails;
    }
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(MainForm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(MainForm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(MainForm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(MainForm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        
        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new MainForm().setVisible(true);
            }
        });
    }
    public JTextField getNameInput() {
        return NameInput;
    }
    public JLabel getCustCode() {
        return custCode;
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel BlockLocations;
    private javax.swing.JComboBox<String> BlockOptions;
    private javax.swing.JLabel BuyerName;
    private javax.swing.JLabel CompanyName;
    private javax.swing.JRadioButton LotSize1;
    private javax.swing.JRadioButton LotSize2;
    private javax.swing.JRadioButton LotSize3;
    private javax.swing.JRadioButton LotSize4;
    private javax.swing.JLabel LotSizes;
    private javax.swing.JTextField NameInput;
    private javax.swing.JLabel PriceDisplay;
    private javax.swing.JLabel PriceLabel;
    private javax.swing.JLabel ProjectTitle;
    private javax.swing.JButton ReportButton;
    private javax.swing.JButton SubmitButton;
    private javax.swing.JLabel cusCodeLabel;
    private javax.swing.JLabel custCode;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    // End of variables declaration//GEN-END:variables
}
